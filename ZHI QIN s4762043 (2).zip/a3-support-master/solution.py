import random
import sys
import time

import numpy as np

from constants import *
from environment import *
from state import State
from tqdm import tqdm
import json
"""
solution.py

This file is a template you should use to implement your solution.

You should implement code for each of the TODO sections below.

COMP3702 2022 Assignment 3 Support Code

Last updated by njc 12/10/22
"""


class RLAgent:

    #
    # TODO: (optional) Define any constants you require here.
    #

    def __init__(self, environment: Environment):
        self.environment = environment
        self.training_reward = 0.0
        self.training_time = 0.0
        self.q_table = self._initialize_q_table()
        self.initial_state = self.environment.get_init_state()
        self.q_learn_epsilon = 0.2
        self.sarsa_epsilon = 0.1
        self.q_learn_stop_ratio = 1.0
        self.sarsa_stop_ratio = 0.95 if abs(self.environment.training_reward_tgt) > 2e5 else 1.0
        self.steps = 0
        self.epochs = 0
        self.training_logs = dict()

    # === Q-learning ===================================================================================================

    def q_learn_train(self):
        """
        Train this RL agent via Q-Learning.
        """
        train_flag = True
        every_50_epoch_reward = 0.0
        while train_flag:
            epoch_start = time.time()
            state = self.initial_state
            pass_flag = False
            while not pass_flag:
                # Select an action
                action = self.q_learn_select_action(state)
                # Take the action
                reward, next_state = self.environment.perform_action(state, action)
                # Update the Q-table
                self._q_learn_update(
                    state=state,
                    action=action,
                    next_state=next_state,
                    reward=reward
                )
                # Update the state
                state = next_state
                # Update the steps
                every_50_epoch_reward += reward
                self.training_reward += reward
                pass_flag = self.environment.is_solved(state)
                self.steps += 1
            epoch_end = time.time()
            self.training_time += epoch_end - epoch_start
            self.epochs += 1
            # if self.epochs % 50 == 0:
            #     self.training_logs[self.epochs] = every_50_epoch_reward / 50
            #     every_50_epoch_reward = 0.0
            #
            # if self.epochs == 10000:
            #     train_flag = False

            if self.training_reward < self.q_learn_stop_ratio * self.environment.training_reward_tgt:
                train_flag = False
            if self.training_time > self.q_learn_stop_ratio * self.environment.training_time_tgt:
                train_flag = False

        with open("q-learn-1.json", "w") as f:
            json.dump(self.training_logs, f, indent=4)

    def q_learn_select_action(self, state: State):
        """
        Select an action to perform based on the values learned from training via Q-learning.
        :param state: the current state
        :return: approximately optimal action for the given state
        """
        # We randomly select an action with probability q_learn_epsilon
        random_number = random.random()
        if random_number < self.q_learn_epsilon:
            action = random.choice(ROBOT_ACTIONS)
        # Otherwise, we select the action with the highest Q-value
        else:
            current_r, current_c = state.robot_posit
            current_orient = state.robot_orient
            action = max(self.q_table[(current_r, current_c, current_orient)],
                         key=self.q_table[(current_r, current_c, current_orient)].get)
        return action

    # === SARSA ========================================================================================================

    def sarsa_train(self):
        """
        Train this RL agent via SARSA.
        """

        train_flag = True
        every_50_epoch_reward = 0.0
        while train_flag:
            epoch_start = time.time()
            state = self.initial_state
            pass_flag = False
            # Select an action first, which is different from Q-learning
            action = self.sarsa_select_action(state)
            while not pass_flag:
                # Take the action
                reward, next_state = self.environment.perform_action(state, action)
                # Choose the next action
                next_action = self.sarsa_select_action(next_state)
                # Update the Q-table
                self._sarsa_update(
                    state=state,
                    action=action,
                    next_state=next_state,
                    next_action=next_action,
                    reward=reward
                )
                # Update the state
                state = next_state
                # Update the action
                action = next_action
                # Update the steps
                self.training_reward += reward
                every_50_epoch_reward += reward
                pass_flag = self.environment.is_solved(state)
                self.steps += 1
            epoch_end = time.time()
            self.training_time += epoch_end - epoch_start
            self.epochs += 1
            # if self.epochs % 50 == 0:
            #     self.training_logs[self.epochs] = every_50_epoch_reward / 50
            #     every_50_epoch_reward = 0.0

            if self.training_reward < self.sarsa_stop_ratio * self.environment.training_reward_tgt:
                train_flag = False
            if self.training_time > self.sarsa_stop_ratio * self.environment.training_time_tgt:
                train_flag = False
            # if self.epochs == 10000:
            #     train_flag = False

        with open("sarsa.json", "w") as f:
            json.dump(self.training_logs, f, indent=4)

    def sarsa_select_action(self, state: State):
        """
        Select an action to perform based on the values learned from training via SARSA.
        :param state: the current state
        :return: approximately optimal action for the given state
        """
        # We randomly select an action with probability q_learn_epsilon
        random_number = random.random()
        if random_number < self.sarsa_epsilon:
            action = random.choice(ROBOT_ACTIONS)
        # Otherwise, we select the action with the highest Q-value
        else:
            current_r, current_c = state.robot_posit
            current_orient = state.robot_orient
            action = max(self.q_table[(current_r, current_c, current_orient)],
                         key=self.q_table[(current_r, current_c, current_orient)].get)
        return action

    # === Helper Methods ===============================================================================================
    #
    #
    # TODO: (optional) Add any additional methods here.
    #
    #

    def _initialize_q_table(self):
        """
        Create a Q-table for the current environment.
        :return: a Q-table for the current environment
        """
        q_table = dict()
        for row in range(self.environment.n_rows):
            for col in range(self.environment.n_cols):
                for orient in ROBOT_ORIENTATIONS:
                    q_table[(row, col, orient)] = {action: 0 for action in ROBOT_ACTIONS}

        return q_table

    def _q_learn_update(self, state: State, action: str, next_state: State, reward: float):
        """
        Update the Q-table based on the current state, action, next state and reward.
        :param state: the current state
        :param action: the action taken
        :param next_state: the next state
        :param reward: the reward received
        """
        current_r, current_c = state.robot_posit
        current_orient = state.robot_orient
        next_r, next_c = next_state.robot_posit
        next_orient = next_state.robot_orient
        max_q = max(self.q_table[(next_r, next_c, next_orient)].values())
        self.q_table[(current_r, current_c, current_orient)][action] += self.environment.alpha * (
                reward + self.environment.gamma * max_q - self.q_table[(current_r, current_c, current_orient)][action])

    def _sarsa_update(self, state: State, action: str, next_state: State, next_action: str, reward: float):
        """
        Update the Q-table based on the current state, action, next state, next action and reward.
        :param state: the current state
        :param action: the action taken
        :param next_state: the next state
        :param next_action: the next action
        :param reward: the reward received
        """
        current_r, current_c = state.robot_posit
        current_orient = state.robot_orient
        next_r, next_c = next_state.robot_posit
        next_orient = next_state.robot_orient
        self.q_table[(current_r, current_c, current_orient)][action] += self.environment.alpha * (
                reward + self.environment.gamma * self.q_table[(next_r, next_c, next_orient)][next_action] -
                self.q_table[(current_r, current_c, current_orient)][action])
