More information will be added here in the future.

For now, refer to the docstring instructions in ```solution.py```, ```environment.py```, ```constants.py``` and ```tester.py``` for usage information for this support code.